<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function __construct() {
		parent:: __construct();
		$this->load->model('login_model');
		$this->load->helper(array('url','form'));
		$this->load->library(array('form_validation','upload','session'));
	
	}


	public function index() {
		$this->load->view('login');
	}

	public function signup() {
		$this->load->view('signup');
	}

	public function activate() {
		$this->load->view('activate');
	}

	public function recover() {
		$this->load->view('recover');
	}


	public function do_signup() {
		$this->form_validation->set_rules('firstname','FirstName','trim|required');
		$this->form_validation->set_rules('lastname','LastName','trim|required');
		$this->form_validation->set_rules('username','UserName','trim|required');
		$this->form_validation->set_rules('email','Email','trim|required|valid_email');
		$this->form_validation->set_rules('password','Passowrd','trim|required');
		$this->form_validation->set_rules('confirm_password','ConfirmPassowrd','trim|required');

		$email = $this->input->post('email');

		$check_email = $this->login_model->check_email($email);

		$check_unverified_email = $this->login_model->check_unverified_email($email);

		$check_username = $this->login_model->check_username();
		

		if(($this->form_validation->run() === FALSE) || $check_email === TRUE || $check_username === TRUE || $check_unverified_email === TRUE) {
			redirect('signup');
		}
		else {
			$name = $this->input->post('firstname');
			$lname = $this->input->post('lastname');
			$username = $this->input->post('username');
			$email = $this->input->post('email');
			$password = password_hash($this->input->post('password'), PASSWORD_DEFAULT);
			$validation_code = md5(uniqid($username,true));

			$user_data = array(
				'user_firstname' => $name,
				'user_lastname' => $lname,
				'username' => $username,
				'user_email' => $email,
				'user_password' => $password,
				'validation_code' => $validation_code
			);
			$this->login_model->user_register($user_data);

			$email = $this->input->post('email');
			$email = $this->input->post('email');

			$url = base_url('user_verification?email='.base64_encode($email).'&validation_code='.base64_encode($validation_code));

			$this->session->set_flashdata('message','A verification link is send to your email');
			$this->session->set_flashdata('link','<a href="'.$url.'">click here</a>');

			redirect('activate');
		}


	}


	public function email_exist() {
		$email= $this->input->post('email');

		if(!filter_var($email,FILTER_VALIDATE_EMAIL)) {
			echo '<p class="text-danger">invalid email</p>';
		}
		else {
			if($this->login_model->check_email($email)) {
				echo '<p class="text-danger">Email already exist</p>';
			}
			elseif($this->login_model->check_unverified_email($email)) {
				echo '<p class="text-danger"><b>X</b> Email not verified</p>';
			}
			else {
				echo '<p class="text-success">Email available</p>';
			}
		}
	}


	public function username_exist() {

		$username = $this->input->post('username');

		if($this->login_model->check_username()) {
			echo '<p class="text-danger">Username already exist</p>';
		}
		else {
			echo '<p class="text-success">Username available</p>';
		}

	}

	public function user_verification() {
		if(isset($_GET['email']) && isset($_GET['validation_code'])) {
			
			$email = base64_decode($_GET['email']);
			$validation_code = base64_decode($_GET['validation_code']);

			if(	filter_var($email,FILTER_VALIDATE_EMAIL)) {
				$this->login_model->verify_user_account($email,$validation_code);
				$this->session->set_flashdata('signup_success','Your account is successfully verified');
				redirect('login');
			}
			else {
				redirect('error');
			}

		}
	}


	public function user_signin() {
		$this->form_validation->set_rules('email','Email','trim|required|valid_email');
		$this->form_validation->set_rules('password','Password','trim|required');

		$email = $this->input->post('email');
		$password = $this->input->post('password');


		$check_unverified_email = $this->login_model->check_unverified_email($email);

		if($this->form_validation->run() === FALSE || $check_unverified_email === TRUE) {
			$this->session->set_flashdata('error','email not verified');
			redirect('login');
		}
		else {
			if($this->login_model->check_email($email)) {

				$udata = $this->login_model->get_user_data($email);

				if(password_verify($password, $udata->user_password))
				{
					setcookie('test','786',time()+60*60*24);
					$newdata = array(
						'id'  => $udata->user_id,
						'firstname'  => $udata->user_firstname,
						'lastname'  => $udata->user_lastname,
						'username'  => $udata->username,
						'email'     => $email,
						'logged_in' => TRUE
					);
					$this->session->set_userdata($newdata);
					redirect(base_url());
				}
				else {
					$this->session->set_flashdata('error','invalid account');
					redirect('login');
				}

			}
			else {
				redirect('login');
			}
		}
	}

	public function sign_user() {

		$this->form_validation->set_rules('email','Email','trim|required|valid_email');
		$email = $this->input->post('email');
		$check_unverified_email = $this->login_model->check_unverified_email($email);
		if($check_unverified_email === TRUE) {
			echo '<p class="text-danger">Email not verified</p>';
		}
		elseif($this->form_validation->run() === FALSE) {
			echo '<p class="text-danger">invalid email</p>';
		}
		else {
			if($this->login_model->check_email($email) == FALSE) {
				echo '<p class="text-danger">Email not contain any account</p>';
			}
		}
	}


	public function logout() {
		$data = array('id' => '','username' =>'','email' =>'','logged_in'=>'');
		$this->session->unset_userdata($data);
		$this->session->sess_destroy();
		redirect('login');
		exit;

	}



	public function recover_password() {

		$email = $this->input->post('email');

		if(!filter_var($email,FILTER_VALIDATE_EMAIL)) {
			$this->session->set_flashdata('error','Invalid email');
			redirect('recover');
		}
		elseif($this->login_model->check_unverified_email($email)) {
			$this->session->set_flashdata('error','Email not verified');
			redirect('recover');
		}
		else {
			if($this->login_model->check_email($email)) {
				$validation_code = mt_rand(100000,999999);
				$this->login_model->password_reset_code($email,base64_encode($validation_code));
				$this->session->set_flashdata('code','Enter the code below to reset your password<br><br><br>'.$validation_code);
				redirect('code?email='.base64_encode($email).'&code='.base64_encode($validation_code));
			}
			else {
				$this->session->set_flashdata('error','account does not exist');
				redirect('recover');

			}
			
		}
	}


	public function code() {

		if(isset($_GET['email']) && isset($_GET['code'])) {

			$email = base64_decode($_GET['email']);
			$code = $_GET['code'];

			if($this->login_model->check_recover_data($email,$code)) {

				$data['email'] = $email;
				$data['code'] = base64_decode($code);
				$this->load->view('code',$data);
			}
			else {
				redirect('error');
			}

		}
		else {
			redirect('error');
		}
		
	}


	public function submit_code() {

		if(isset($_GET['email']) && isset($_GET['code'])) {
			$validation_code = $_GET['code'];
			$email = $_GET['email'];
			if($this->login_model->check_recover_data($email,base64_encode($validation_code))) {

				$code = $this->input->post('code');
				if($this->login_model->check_recover_data($email,base64_encode($code))) {
					redirect('reset?email='.base64_encode($email).'&code='.base64_encode($code));
				}
				else {
					$this->session->set_flashdata('error','code not matched');
					redirect('code?email='.base64_encode($email).'&code='.base64_encode($validation_code));
				}
			}
			else {
				redirect('error');
			}
			
		}
		else {
			redirect('error');
		}
	}


	public function reset() {

		if(isset($_GET['email']) && isset($_GET['code'])) {
			$email = base64_decode($_GET['email']);
			$code = $_GET['code'];
			if($this->login_model->check_recover_data($email,$code)) {
				$data['email'] = $email;
				$data['code'] = $code;
				$this->load->view('reset_password',$data);
			}
			else {
				redirect('error');
			}
		}
		else {
			redirect('error');
		}
		
	}

	public function reset_password() {

		if(isset($_GET['email']) && isset($_GET['code'])) {
			$validation_code = $_GET['code'];
			$email = $_GET['email'];
			if($this->login_model->check_recover_data($email,$validation_code)) {

				$password = $this->input->post('password');
				$password = password_hash($password, PASSWORD_DEFAULT);
				$this->login_model->update_password($email,$validation_code,$password);
				$this->session->set_flashdata('signup_success','your password reset successfully');
				redirect('login');
			}
			else {
				redirect('error');
			}
			
		}
		else {
			redirect('error');
		}

	}









}




?>