<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Posts extends CI_Controller {

	public function __construct() {
		parent:: __construct();
		$this->load->model('post_model');
		$this->load->helper(array('url','form'));
		$this->load->library(array('form_validation','session','pagination','calendar'));
		
	}

	public function index()
	{
		$config = [
			'base_url' => base_url('posts/index'),
			'per_page' => 2,
			'total_rows' => $this->post_model->all_posts()	];

		$this->pagination->initialize($config);

		$data['category'] = $this->post_model->all_category();
		$data['posts'] = $this->post_model->get_posts($config['per_page'],
						 $this->uri->segment(3));
		$this->load->view('includes/header.php');
		$this->load->view('index.php',$data);
		$this->load->view('includes/footer.php');
	}

	public function post($id)
	{
		$data['category'] = $this->post_model->all_category();
		$data['post'] = $this->post_model->get_post($id);
		$data['comment'] = $this->post_model->get_comment($id);
		$this->load->view('includes/header');
		$this->load->view('post',$data);
		$this->load->view('includes/footer');
	}

	public function search($query = '') {

		

			$data['category'] = $this->post_model->all_category();
			$data['search'] = $this->post_model->search_data($query);
			
			$this->load->view('search.php',$data);
		
	}

	public function create_new_comment($id) {

		if($this->session->userdata('logged_in') == TRUE) {
			$this->post_model->add_comment($id);
		}
		
		redirect('post/'.$id);
	}

	public function error() {
		$this->load->view('includes/showError');
	}

	public function SearchByCategory($category)
	{
		$id = $this->post_model->SearchByCategory($category);
		$posts = $this->post_model->PostByCategory($id);
		foreach ($posts as  $p) {
			echo '<pre>';
			var_dump($p);
		}
	}

	public function test()
	{
		$this->load->view('text.php');
	}

	public function test2()
	{
		$arr = md5(rand(0,999));
		echo substr($arr, 10,6);
		header("Arif");
	}


}
