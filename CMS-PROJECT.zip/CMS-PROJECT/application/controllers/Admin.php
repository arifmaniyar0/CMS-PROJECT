<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	public function __construct() {
		parent:: __construct();
		$this->load->model('admin_model');
		$this->load->helper(array('url','form','text'));
		$this->load->library(array('form_validation','upload','session'));
	}


	public function index() {

		$data['total_posts'] = $this->admin_model->total_posts();
		$data['total_comments'] = $this->admin_model->total_comments();
		$data['total_users'] = $this->admin_model->total_users();
		$data['total_categories'] = $this->admin_model->total_categories();
                    

		$this->load->view('admin/includes/header.php');
		$this->load->view('admin/index',$data);
		$this->load->view('admin/includes/footer.php');
		
	}

	public function all_posts() {
		
		$data['posts'] = $this->admin_model->get_post();
		

		$this->load->view('admin/includes/header.php');
		$this->load->view('admin/posts',$data);
		$this->load->view('admin/includes/footer.php');
	}


	public function delete_post($id) {
		
		$this->admin_model->delete_post($id);
		redirect('all_posts');
	}

	public function edit_post($id) {
		
		$data['post'] = $this->admin_model->view_editpost($id);
		$data['cat'] = $this->admin_model->category();
		$data['error'] ='';
		$this->load->view('admin/includes/header');
		$this->load->view('admin/includes/edit_post',$data);
		$this->load->view('admin/includes/footer');
	}

	public function update_post($id) {
			$config = array(
				'upload_path' => './assets/images/', 
				'allowed_types' => 'jpg|jpeg|png|gif',
				'max_size' => 2048,
				'overwrite' => TRUE
			);
			$this->upload->initialize($config);
			$this->upload->do_upload('file');

			if(!$this->upload->do_upload('file'))
			{
				$data['post'] = $this->admin_model->view_editpost($id);
				$data['cat'] = $this->admin_model->category();
				$this->admin_model->update_editpost($id,$data['post'][0]->post_image);
				redirect('all_posts');
			}
			else {
				$file_name = $this->upload->data('file_name');
				$this->admin_model->update_editpost($id,$file_name);
				redirect('all_posts');
			}
			
	}

	public function add_post() {
		$data['cat'] = $this->admin_model->category();
		$data['error'] = '';
		$this->load->view('admin/includes/header');
		$this->load->view('admin/includes/add_post',$data);
		$this->load->view('admin/includes/footer');
	}


	public function create_post() {

		$this->form_validation->set_rules('post_title','Title','trim|required');
		$this->form_validation->set_rules('post_category','Category','trim|required');
		$this->form_validation->set_rules('post_author','Author','trim|required');
		$this->form_validation->set_rules('post_content','Content','trim|required');
		$this->form_validation->set_rules('post_tags','Tags','trim|required');

		$config = array(
				'upload_path' => './assets/images/', 
				'allowed_types' => 'jpg|jpeg|png|gif',
				'max_size' => 2048,
			);
			$this->upload->initialize($config);
			$this->upload->do_upload('file');

			if(($this->form_validation->run() === FALSE) || !($this->upload->do_upload('file')))
			{
				$data['cat'] = $this->admin_model->category();
				$data['error'] =  $this->upload->display_errors();
				$this->load->view('admin/includes/header');
				$this->load->view('admin/includes/add_post',$data);
				$this->load->view('admin/includes/footer');
			}
			else {
				$file_name = $this->upload->data('file_name');
				$this->admin_model->create_post($file_name);
				redirect('all_posts');
			}
	}

	public function categories() {
		$data['cat'] = $this->admin_model->category();
		$this->load->view('admin/includes/header');
		$this->load->view('admin/category',$data);
		$this->load->view('admin/includes/footer');
	}

	public function add_category() {
		$this->form_validation->set_rules('category','Category','trim|required');
		if($this->form_validation->run() === FALSE) {
			$data['cat'] = $this->admin_model->category();
			$this->load->view('admin/includes/header');
			$this->load->view('admin/category',$data);
			$this->load->view('admin/includes/footer');
		}
		else {
			$this->admin_model->add_cat();
			redirect('categories');
		}
	}


	public function update_cat($id) {
		$data['cat'] = $this->admin_model->get_editcat($id);
		$output = '<h3 style="padding-left: 15px">Update Category</h3><form method="post" name="update_cat" action="'.base_url("update_category/$id").'">
	                    <div class="col-md-8">
	                    <input class="form-control" class="input-control" type="text" name="cat" value="'.$data['cat'][0]->cat_title.'"></div>
	                    <input class="btn btn-primary" type="submit" name="submit" value="Update">
	                </form>';
        echo $output;
	}

	public function update_category($id) {
		$this->admin_model->update_category($id);
		redirect('categories');
	}

	public function delete_cat($id) {
		$this->admin_model->del_cat($id);
	}


	public function all_users() {
		$data['users'] = $this->admin_model->all_users();
		$this->load->view('admin/includes/header');
		$this->load->view('admin/users',$data);
		$this->load->view('admin/includes/footer');
	}

	public function delete_user($id) {

		$this->admin_model->del_user($id);

	}


	public function edit_user($id) {

		$data['user'] = $this->admin_model->user_data($id);
		// $this->load->view('admin/includes/header');
		$this->load->view('admin/includes/edit_user',$data);
		// $this->load->view('admin/includes/footer');
	}

	public function update_user($id) {

		$u = $this->admin_model->user_data($id);

		$firstname = $this->input->post('firstname');
		$lastname = $this->input->post('lastname');
		$username = $this->input->post('username');
		$email = $this->input->post('email');
		if(filter_var($email,FILTER_VALIDATE_EMAIL)) {
			if($this->admin_model->email_availability($email,$u->user_email) && 
			   $this->admin_model->username_availability($username,$u->username)) {
				$data['error'] = 'email or username already exist';
			}
			else {
				$this->admin_model->update_user_data($id,$firstname,$lastname,$username,$email);
			redirect('all_users');
			}
			
		}
		
	}


	public function add_user() {

		$this->load->view('admin/includes/header');
		$this->load->view('admin/includes/add_user');
		$this->load->view('admin/includes/footer');

	}


	public function submit_new_user() {

		$firstname = $this->input->post('firstname');
		$lastname = $this->input->post('lastname');
		$email = $this->input->post('email');
		$username = $this->input->post('username');
		$password = $this->input->post('password');


		$this->load->model('login_model');
		$email_exist = $this->login_model->check_email($email);
		$unverified_email = $this->login_model->check_unverified_email($email);
		$username_exist = $this->login_model->check_username();

		if($email_exist == TRUE || $unverified_email == TRUE || $username_exist == TRUE) {
			redirect('add_user');
		}
		else {
			$this->admin_model->create_new_user($firstname,$lastname,$username,$email,$password);
			$this->session->set_flashdata('create_user','new user is created');
			redirect('add_user');
		}
	}


	public function comments() {

		$data['comments'] = $this->admin_model->all_comments();
		
		$this->load->view('admin/includes/header');
		$this->load->view('admin/comments',$data);
		$this->load->view('admin/includes/footer');
	}


	public function delete_comment($id) {
		$this->admin_model->user_delete($id);
	}

	public function approve_comment($id) {
		$this->admin_model->comment_approve($id);
	}

	public function unapprove_comment($id) {
		$this->admin_model->comment_unapprove($id);
	}

	public function publish_post($id) {
		$this->admin_model->post_publish($id);
	}

	public function draft_post($id) {
		$this->admin_model->post_draft($id);
	}


	public function checkboxes() {
		
		if($this->input->post('select')) {

			if(isset($_POST['selectall'])) {
				$checkbox_data = $_POST['selectall'];
				$select_length = count($checkbox_data);
			}
			
			$select = $this->input->post('select');
			
			if($select == 'publish') {
				for($i = 0; $i < $select_length; $i++) {
					$this->admin_model->post_publish($checkbox_data[$i]);
				}
			}
			elseif($select == 'draft') {
				for($i = 0; $i < $select_length; $i++) {
					$this->admin_model->post_draft($checkbox_data[$i]);
				}
			}
			elseif($select == 'clone') {
				for($i = 0; $i < $select_length; $i++) {
					$this->admin_model->post_clone($checkbox_data[$i]);
				}
			}
			elseif($select == 'delete') {
				for($i = 0; $i < $select_length; $i++) {
					$this->admin_model->delete_post($checkbox_data[$i]);
				}
			}
			else {
				echo 'choose one of them';
			}

			redirect('all_posts');	
		}

		else {
			redirect('all_posts');
		}
		
	}



	

	














}
?>