

    <div id="wrapper">

        <!-- Navigation -->
        <?php $this->load->view('admin/includes/navigation.php'); ?>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Update Post
                            <small>Subheading</small>
                        </h1>
                        
                    </div>


                </div>
                <!-- /.row -->
                   <div>
                       
                    <form class="form" method="post" action="<?= base_url(); ?>update_post/<?= $post[0]->post_id ?>" enctype="multipart/form-data">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Title</label>
                                <input class="form-control" type="text" value="<?= $post[0]->post_title ?>" name="post_title">
                            </div>

                             <div class="form-group">
                                <label>Category</label>
                               <select class="form-control" name="post_category">
                                   <?php foreach($cat as $c) { 
                                    $selected = "";
                                    if($post[0]->post_category_id == $c->cat_id)
                                    {
                                        $selected = 'selected';
                                    }     ?>
                                   <option value="<?php echo $c->cat_id; ?>" <?= $selected; ?>><?php echo $c->cat_title; ?></option>
                                    <?php } ?>
                               </select>
                            </div>

                             <div class="form-group">
                                <label>Author</label>
                                <input class="form-control" type="text" value="<?= $post[0]->post_author ?>" name="post_author">
                            </div>

                             <div class="form-group">
                                <label>Image</label><?= $error; ?>
                                <input class="form-control" type="file" name="file">
                               <p id="image1"><img class="img-responsive" width="100" src="<?= base_url('assets/images/'.$post[0]->post_image) ?>"></p>
                            </div>

                             <div class="form-group">
                                <label>Content</label>
                                <input class="form-control" type="text" value="<?= $post[0]->post_content ?>" name="post_content">
                            </div>

                             <div class="form-group">
                                <label>Status</label>
                                <select name="post_status">
                                    <option value="published">publish</option>
                                    <option value="draft">draft</option>
                                </select>
                            </div>

                             <div>
                                <input class="btn btn-success" type="submit" value="Update" name="submit">
                            </div>
                            
                        </div>
                    </form>


                   </div> 
            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
  
