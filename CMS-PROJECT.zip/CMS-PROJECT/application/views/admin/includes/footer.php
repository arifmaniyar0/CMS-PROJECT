 <script src="<?= base_url(); ?>assets/admin/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?= base_url(); ?>assets/admin/js/bootstrap.min.js"></script>



    <!-- javascript Core  -->
    <script src="<?= base_url(); ?>assets/admin/js/style.js"></script>

</body>

</html>