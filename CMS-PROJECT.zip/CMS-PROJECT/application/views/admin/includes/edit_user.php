

    <div id="wrapper">

        <!-- Navigation -->
        <?php $this->load->view('admin/includes/navigation.php'); ?>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        
                        
                        <div class="col-lg-8 col-lg-offset-2">

                        	<h1>Edit User</h1>


                        	<hr>

                        	<div class="row">
                        		
                        		<div class="panel-body">
						<div class="row">
							<div class="col-lg-12">
								<form id="edit_user_form" name="edit_user" action="update_user/<?= $user->user_id; ?>" method="post">

									<div class="form-group"><?= form_error('firstname'); ?>
										<input type="text" name="firstname" id="firstname" tabindex="1" class="form-control" placeholder="Firstname" value="<?= $user->user_firstname; ?>" required ><small id="firstname_check" class="text-danger"></small>
									</div>
									<div class="form-group"><?= form_error('lastname'); ?>
										<input type="text" name="lastname" id="lastname" tabindex="1" class="form-control" placeholder="Lastname" value="<?= $user->user_lastname; ?>" required ><small id="lastname_check" class="text-danger"></small>
									</div>
									<div class="form-group"><?= form_error('username'); ?>
										<input type="text" name="username" id="username" tabindex="1" class="form-control" placeholder="Username" value="<?= $user->username; ?>" required ><small id="username_check"></small>
									</div>
									<div class="form-group"><?= form_error('email'); ?>
										<input type="email" name="email" id="register_email" tabindex="1" class="form-control" placeholder="Email Address" value="<?= $user->user_email; ?>" required ><small id="email_check"></small>
									</div>
									
									
									<div class="form-group">
										<div class="row">
											<div class="col-sm-4 col-sm-offset-3">
												<input type="submit" name="register-submit" id="edit_user-submit" tabindex="4" class="form-control btn btn-success" value="Register Now">
											</div>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>

                        	</div>
                            

                        </div>
                        
                        </tbody>
                    </table>


                        </div>
                    </div>
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
 

 <script type="text/javascript">
$(document).ready(function() {


	var fname = false;
	var lname = false;


$('#firstname_check').hide();
$('#lastname_check').hide();
	

	function check_firstname() {
		$('#firstname').focusout(function() {
			var firstname = $('#firstname').val();
			if(firstname === '') {
				$('#firstname_check').show();
				$('#firstname_check').html('Enter firstname');
				fname = false;
			}
			else { 
				$('#firstname_check').hide();
				fname = true;
		   }
		});
	} 
	
	function check_lastname() {
		$('#lastname').focusout(function() {
			var lastname = $('#lastname').val();
			if(lastname === '') {
				$('#lastname_check').show();
				$('#lastname_check').text('Enter lastname');
				lname = false;
			}
			else {
				$('#lastname_check').hide();
				lname = true;
			}
		});
	}

	function check_email() {
		$('#register_email').change(function() {
			var email = $('#register_email').val();
			
			if(email != '') {

				$.ajax({
					url : '<?php echo base_url() ?>login/email_exist',
					method : 'POST',
					data : {email:email},
					success : function(data) {
						$('#email_check').html(data);
						
					}
				});
			}
		});
	}



	function check_username() {
		$('#username').change(function() {
			var username = $('#username').val();
			console.log(username);
			if(username != '') {
				$.ajax({
					url : '<?php echo base_url() ?>login/username_exist',
					method : 'POST',
					data : {username : username},
					success : function(data) {
						$('#username_check').html(data);
					}
				});
			}
		});
	}

	
	var fname = false;
	var lname = false;

	check_firstname();
	check_lastname();
	uname = check_username();
	gname = check_email();


		

	$('#edit_user_form').on('submit',function(event) {

		
		if($('#firstname').val() != '' && $('#lastname').val() != '' && $('#email').val() != '' && $('#username').val() != '') {
			return true;
		}
			return false;
	});


	


});

</script>