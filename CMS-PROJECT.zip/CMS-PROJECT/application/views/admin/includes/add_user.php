

    <div id="wrapper">

        <!-- Navigation -->
        <?php $this->load->view('admin/includes/navigation.php'); ?>

        <div id="page-wrapper">

            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                         <?php if($this->session->flashdata('create_user')) { ?>
                        <div class="col-md-6 col-md-offset-3">
                            <div class="alert alert-success alert-dismissible text-center">
                                <?php echo $this->session->flashdata('create_user'); ?> 
                            </div>
                        </div>
                         <?php } ?>
                    </div>
                </div>

               
                <!-- Page Heading -->
                <div class="row">
                    <div id="here" class="col-lg-8 col-lg-offset-2">
                        
                        <h1 class="page-header">
                            Add User
                            <small>Subheading</small>
                        </h1>

                        <form id="register_form" name="signup" action="submit_new_user" method="post">

                                    <div class="form-group"><?= form_error('firstname'); ?>
                                        <input type="text" name="firstname" id="firstname" tabindex="1" class="form-control" placeholder="Firstname" value="<?= set_value('firstname'); ?>" required ><small id="firstname_check" class="text-danger"></small>
                                    </div>
                                    <div class="form-group"><?= form_error('lastname'); ?>
                                        <input type="text" name="lastname" id="lastname" tabindex="1" class="form-control" placeholder="Lastname" value="<?= set_value('lastname'); ?>" required ><small id="lastname_check" class="text-danger"></small>
                                    </div>
                                    <div class="form-group"><?= form_error('username'); ?>
                                        <input type="text" name="username" id="username" tabindex="1" class="form-control" placeholder="Username" value="<?= set_value('username'); ?>" required ><small id="username_check"></small>
                                    </div>
                                    <div class="form-group"><?= form_error('email'); ?>
                                        <input type="email" name="email" id="register_email" tabindex="1" class="form-control" placeholder="Email Address" value="<?= set_value('email'); ?>" required ><small id="email_check"></small>
                                    </div>
                                    <div class="form-group"><?= form_error('password'); ?>
                                    <span id="passErr"></span>
                                        <input type="password" name="password" id="password" tabindex="2" class="form-control" placeholder="Password" required><small id="password_check" class="text-danger"></small>
                                    </div>
                                    <div class="form-group">
                                        <?= form_error('confirm_password'); ?>
                                        <input type="password" name="confirm_password" id="con_password" tabindex="2" class="form-control" placeholder="Confirm Password" required><small id="con_password_check" class="text-danger"></small>
                                    </div>
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-4 col-sm-offset-4">
                                                <input type="submit" name="register-submit" id="register-submit" tabindex="4" class="form-control btn btn-success" value="Register Now">
                                            </div>
                                        </div>
                                    </div>
                                </form>


                        
                        </tbody>
                    </table>


                        </div>
                    </div>
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
   
<script type="text/javascript">
$(document).ready(function() {


    var fname = false;
    var lname = false;
    var uname = false;
    var gmail = false;
    var pass = false;
    var cpass = false;


$('#firstname_check').hide();
$('#lastname_check').hide();
$('#password_check').hide();
$('#con_password_check').hide();

    

    function check_firstname() {
        $('#firstname').focusout(function() {
            var firstname = $('#firstname').val();
            if(firstname === '') {
                $('#firstname_check').show();
                $('#firstname_check').html('Enter firstname');
                fname = false;
            }
            else { 
                $('#firstname_check').hide();
                fname = true;
           }
        });
    } 
    
    function check_lastname() {
        $('#lastname').focusout(function() {
            var lastname = $('#lastname').val();
            if(lastname === '') {
                $('#lastname_check').show();
                $('#lastname_check').text('Enter lastname');
                lname = false;
            }
            else {
                $('#lastname_check').hide();
                lname = true;
            }
        });
    }

    function check_email() {
        $('#register_email').change(function() {
            var email = $('#register_email').val();
            
            if(email != '') {

                $.ajax({
                    url : '<?php echo base_url() ?>login/email_exist',
                    method : 'POST',
                    data : {email:email},
                    success : function(data) {
                        $('#email_check').html(data);
                        
                    }
                });
            }
        });
    }



    function check_username() {
        $('#username').change(function() {
            var username = $('#username').val();
            console.log(username);
            if(username != '') {
                $.ajax({
                    url : '<?php echo base_url() ?>login/username_exist',
                    method : 'POST',
                    data : {username : username},
                    success : function(data) {
                        $('#username_check').html(data);
                    }
                });
            }
        });
    }

    function check_password() {
        $('#password').focusout(function() {
            var password = $('#password').val();
            if(password === '') {
                $('#password_check').show();
                $('#password_check').text('Enter password');
                pass = false;
            }
            else {
                if(password.length < 3) {
                    $('#password_check').show();
                    $('#password_check').text(' password must be at least 3 character long');
                    pass = false;
                }
                else {
                    $('#password_check').hide();
                    pass = true;
                }
            }
            
        });
    }

    function check_con_password() {
        $('#con_password').change(function() {
            var con_password = $('#con_password').val();
            if(con_password === '') {
                $('#con_password_check').show();
                $('#con_password_check').text('Enter password');
                cpass = false;
            }
            else {
                if($('#password').val() != $('#con_password').val()) {
                    $('#password_check').show();
                    $('#password_check').text('password not matched');
                    cpass = false;
                }
                else {
                    $('#con_password_check').hide();
                    cpass = true;
                }
                
            }
        });
    }

        
    
        
    var fname = false;
    var lname = false;
    var pass = false;
    var cpass = false;

    check_firstname();
    check_lastname();
    uname = check_username();
    gname = check_email();
    check_password();
    check_con_password();


        

    $('#register_form').on('submit',function(event) {

        
        if(fname == true && lname == true && pass == true && cpass == true) {
            return true;
        }
        else {
            return false;
        }
    });


});

</script>