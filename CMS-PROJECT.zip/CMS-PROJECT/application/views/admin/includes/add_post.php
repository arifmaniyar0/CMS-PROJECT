

    <div id="wrapper">

        <!-- Navigation -->
        <?php $this->load->view('admin/includes/navigation.php'); ?>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Create Post
                            <small>Subheading</small>
                        </h1>
                        
                    </div>


                </div>
                <!-- /.row -->
                   <div>
                       
                    <form class="form" method="post" action="<?= base_url(); ?>create_post" enctype="multipart/form-data">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Title</label><?php echo form_error('post_title'); ?>
                                <input class="form-control" type="text" value="<?= set_value('post_title'); ?>" name="post_title">
                            </div>

                             <div class="form-group">
                                <label>Category</label>
                               <select class="form-control" name="post_category">
                                   <?php foreach($cat as $c) { 
                                    ?>
                                   <option value="<?php echo $c->cat_id; ?>"><?php echo $c->cat_title; ?></option>
                                    <?php } ?>
                               </select>
                            </div>

                             <div class="form-group">
                                <label>Author</label><?= form_error('post_author'); ?>
                                <input class="form-control" type="text" value="<?= set_value('post_author'); ?>" name="post_author">
                            </div>

                             <div class="form-group">
                                <label>Image</label><?= $error; ?>
                                <input class="form-control" type="file" name="file">
                            </div>

                             <div class="form-group">
                                <label>Content</label><?= form_error('post_content'); ?>
                                <input class="form-control" type="text" value="<?= set_value('post_content'); ?>" name="post_content">
                            </div>

                             <div class="form-group">
                                <label>Tag</label><?= form_error('post_tags'); ?>
                                <input class="form-control" type="text" value="<?= set_value('post_tags'); ?>" name="post_tags">
                            </div>

                             <div class="form-group">
                                <label>Status</label>
                                <select name="post_status">
                                    <option value="published">publish</option>
                                    <option value="draft">draft</option>
                                </select>
                            </div>

                             <div>
                                <input class="btn btn-success" type="submit" value="Create" name="submit">
                            </div>
                            
                        </div>
                    </form>


                   </div> 
            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    
