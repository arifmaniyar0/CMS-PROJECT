

<div id="wrapper">

    <!-- Navigation -->
    <?php $this->load->view('admin/includes/navigation.php'); ?>

    <div id="page-wrapper">

        <div class="container-fluid">

            <!-- Page Heading -->
            <div class="row">
                <div class="col-lg-12">
                    <form id="select_form" class="form" method="post" action="checkboxes">
                    <h1 class="page-header">
                        Blank Page
                        <small>Subheading</small>
                    </h1>
                    <div class="col-lg-8">

                            <div id="form_option" class="form-group">
                                <div class="col-lg-6"><small id="select_error"></small>
                                    <select id="select_option" class="form-control" name="select">
                                        <option value="">choose one</option>
                                        <option value="publish">publish</option>
                                        <option value="draft">draft</option>
                                        <option value="clone">clone</option>
                                        <option value="delete">delete</option>
                                    </select>
                                </div>
                                
                                <button id="checkbox_data" class="btn btn-primary">Submit</button>
                                <a class="btn btn-success" href="add_post">Add Post</a>
                            </div>

                        <hr>
                    </div>


                    <div>
                       <table class="table table-responsive">
                          <thead>
                             <tr>
                                <td><input id="checkboxes" type="checkbox"></td>
                                <td>S No</td>
                                <td>Title</td>
                                <td>Category</td>
                                <td>Author</td>
                                <td>Image</td>
                                <td>Content</td>
                                <td>Comments</td>
                                <td>Status</td>
                                <td colspan="2">Status Action</td>
                                <td>Post</td>
                                <td colspan="2">Action</td>
                            </tr>
                        </thead>
                        <tbody>
                        
                         	<?php $i=1; foreach($posts as $post) { ?>

                        		<tr>
                                    <td><input id="select_data" class="checkbox" type="checkbox" name="selectall[]" value="<?= $post->post_id;  ?>"></td>
                                    <td><?= $i ?></td>
                                    <td><?= $post->post_title; ?></td>
                                    <?php 
                                    $cat = $this->admin_model->get_cat($post->post_category_id);
                                    $category = $cat->cat_title;
                                    
                                    ?>
                                    <td><?= $category; ?></td>
                                    <td><?= $post->post_author; ?></td>
                                    <td><img width="100" src="<?= base_url(); ?>assets/images/<?= $post->post_image ?>"></td>
                                    <td><?= word_limiter($post->post_content,3); ?></td>
                                    <?php 
                                    $total_comments = $this->admin_model->count_comment($post->post_id);

                                    ?>
                                    <td><?= $total_comments; ?></td>
                                    <td><?= $post->post_status; ?></td>
                                    <td><button class="btn btn-default" onclick="publish_post(<?= $post->post_id; ?>)">Publish</button></td>
                                    <td><button class="btn btn-default" onclick="draft_post(<?= $post->post_id; ?>)">Draft</button></td>
                                    <td><a class="btn btn-default" href="post/<?= $post->post_id; ?>">view_post</a></td>
                                    <td><a class="btn btn-default" href="<?= base_url(); ?>edit_post/<?= $post->post_id; ?>"><i class="fa fa-edit"></i></a></td>
                                    <td><a class="btn btn-default" onclick="return delete_post()" href="<?= base_url(); ?>/delete_post/<?= $post->post_id; ?>"><i class="fa fa-trash"></i></a></td>
                                </tr>

                                <?php $i++; } ?>
                            </tbody>
                        </table>

                    </div>
                
                </div></form>
            </div>
            <!-- /.row -->

        </div>
        <!-- /.container-fluid -->

    </div>
    <!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->

<!-- jQuery -->

<script type="text/javascript">


    function delete_post() {
        if(confirm('are you sure?')) {
            return true;
        }
        else {
            return false;
        }
    }

    function publish_post(id) {
        console.log(id);
        $.ajax({
            url : '<?php echo base_url(); ?>publish_post/'+id,
            method : 'POST',
            data : {id:id},
            success : function(data) {
                window.location.href = 'all_posts';
            }
        });
    }


    function draft_post(id) {
        console.log(id);
        $.ajax({
            url : '<?php echo base_url(); ?>draft_post/'+id,
            method : 'POST',
            data : {id:id},
            success : function(data) {
                window.location.href = 'all_posts';
            }
        });
    }


    // $('#form_option').hide();

    // $('.checkbox').on('change',function() {
    //     if(this.checked) {
    //         $('#form_option').show();
    //     }
    //     else {
    //         $('.checkbox').each(function(){ 
    //             if(!this.checked) {
    //                  $('#checkboxes').prop('checked',false);
    //             }
                
    //          });

    //     }
        
    // });
   
   
    

    $('#checkboxes').on('click',function() {
        if(this.checked) {
            $('.checkbox').each(function() {
                $('.checkbox').prop('checked',true);
                $('#form_option').show();
            });
        }
        else {
            $('.checkbox').prop('checked',false);
            $('#form_option').hide();
        }
    });


    $('#select_form').on('submit',function() {
        var val = $('#select_option').val();
        if(val == '') {
            $('#select_error').html('<p class="text-danger">choose one option</p>');
            return false;
        }
        return true;
        
    });



</script>