

    <div id="wrapper">

        <!-- Navigation -->
        <?php $this->load->view('admin/includes/navigation.php'); ?>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Comments
                            <small>Subheading</small>
                        </h1>
                       <table class="table">
                        <thead>
                            <tr>
                                <td>S No</td>
                                <td>Post</td>
                                <td>User</td>
                                <td>Author</td>
                                <td>Email</td>
                                <td>Content</td>
                                <td>Status</td>
                                <td colspan="2">Status Action</td>
                                <td>Action</td>
                            </tr>
                        </thead>
                        <tbody>
                       <?php $i = 1; foreach($comments as $c) { ?>
                        <tr>
                            <td><?= $i; ?></td>
                            <?php $this->load->model('admin_model');
                                  $posts = $this->admin_model->get_comment_post($c->comment_post_id);
                                  $post = $posts->post_title; ?>
                            <td>
                                <a href="<?= base_url(); ?>post/<?= $posts->post_id; ?>"><?= $post; ?></a>
                            </td>
                            <?php $this->load->model('admin_model');
                                  $users = $this->admin_model->user_data($c->comment_user_id);
                                  $username = $users->username ?>
                            <td><?= $username; ?></td>
                            <td><?= $c->comment_author; ?></td>
                            <td><?= $c->comment_email; ?></td>
                            <td><?= word_limiter($c->comment_content,3); ?></td>
                            <td><?= $c->comment_status; ?></td>
                            <td><button class="btn btn-default" onclick="approve_comment(<?= $c->comment_id; ?>)">approve</button></td>
                            <td><button class="btn btn-default" onclick="unapprove_comment(<?= $c->comment_id; ?>)">unapprove</button></td>
                            <td><button id="delete_comment" onclick="delete_com(<?= $c->comment_id; ?>)" class="btn btn-default"><i class="fa fa-trash"></i></button></td>
                        </tr>
                       <?php $i++; } ?>
                        </tbody>
                    </table>
                    </div>
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
   

<script type="text/javascript">
    
    function delete_com(id) { 

        if(confirm('are you sure?')) {

            $.ajax({
                url : '<?php echo base_url(); ?>delete_comment/'+id,
                method : 'POST',
                data : {id:id},
                success : function(data) {
                    window.location.href = "comments";
                }
            });

        }
        else {
            return false;
        }
        
    }

    function approve_comment(id) {
        console.log(id);

        $.ajax({
            url : '<?php echo base_url(); ?>approve_comment/'+id,
            method : 'POST',
            data : {id:id},
            success : function(data) {
                window.location.href = "comments";
            }
        });

    }

    function unapprove_comment(id) {
        console.log(id);

        $.ajax({
            url : '<?php echo base_url(); ?>unapprove_comment/'+id,
            method : 'POST',
            data : {id:id},
            success : function(data) {
                window.location.href = "comments";
            }
        });
    }


    
</script>
