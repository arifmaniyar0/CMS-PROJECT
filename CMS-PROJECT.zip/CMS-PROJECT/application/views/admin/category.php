

<div id="wrapper">

    <!-- Navigation -->
    <?php $this->load->view('admin/includes/navigation.php'); ?>

    <div id="page-wrapper">

        <div class="container-fluid">

            <!-- Page Heading -->
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">
                        Blank Page
                        <small>Subheading</small>
                    </h1>

                </div>




                <div class="col-md-6">
                    <table class="table table-responsive">
                        <thead>
                            <tr>
                                <th>S No</th>
                                <th>Categories</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i = 1; foreach($cat as $c) { ?>
                                <tr>
                                    <td><?= $i; ?></td>
                                    <td><?= $c->cat_title; ?></td>
                                    <td ><button class="btn btn-default" onclick="edit_cat(<?= $c->cat_id ?>)">Edit</button></td>
                                    <td ><button class="btn btn-default" onclick="delete_cat(<?= $c->cat_id ?>)">Delete</button></td>
                                </tr>
                                <?php $i++; } ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="col-md-6">
                        <div style="padding: 0;">
                        <h3 style="padding-left: 15px">Create Category</h3>
                        <form method="post" action="<?= base_url(); ?>add_category">
                            <?= form_error('category'); ?>
                            <div class="col-md-8">
                                <input class="form-control" class="input-control" type="text" name="category">
                            </div>
                            <input class="btn btn-primary" type="submit" name="submit" value="Add Category">
                        </form>
                    </div>
                            <hr>
                            <div id="edit_form" class="col-md-12" style="padding: 0;">

                            </div>
                        </div>
                    </div>
                    <!-- /.row -->

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- /#page-wrapper -->

        </div>
        <!-- /#wrapper -->

        <!-- jQuery -->


