

    <div id="wrapper">

        <!-- Navigation -->
        <?php $this->load->view('admin/includes/navigation.php'); ?>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div id="here" class="col-lg-12">
                        <h1 class="page-header">
                            All Users
                            <small>Subheading</small>
                        </h1>
                        

                        <div class="row">

                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>S No</th>
                                        <th>First Name</th>
                                        <th>Last Name</th>
                                        <th>Username</th>
                                        <th>Email</th>
                                        <th>Status</th>
                                        <th colspan="2">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 1; foreach($users as $u) { ?>
                                    <tr>
                                        <td><?= $i; ?></td>
                                        <td><?= $u->user_firstname; ?></td>
                                        <td><?= $u->user_lastname; ?></td>
                                        <td><?= $u->username; ?></td>
                                        <td><?= $u->user_email; ?></td>
                                        <?php if($u->user_active == 1) { 
                                            $active = 'active';
                                            } else {
                                                $active = 'unactive';
                                            } ?>
                                        <td><?= $active; ?></td>
                                        <td><button class="btn btn-default" onclick="edit_user(<?= $u->user_id; ?>)"><i class="fa fa-edit"></i></button></td>
                                        <td>
                                            <?php if($u->user_id != $this->session->userdata('id')) {
                                                ?>
                                            <button id="user_delete" class="btn btn-default" onclick="del_user(<?= $u->user_id; ?>)"><i class="fa fa-trash"></i></button>
                                        <?php } ?>
                                        </td>
                                    </tr>
                                    <?php $i++; } ?>
                                </tbody>
                            </table>
                        </div>
                        

                        </div>
                    </div>
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
   
<script type="text/javascript">
   

    function del_user(id) {

        if(confirm('are you sure?')) {
            $.ajax({
                url : 'delete_user/'+id,
                method : 'POST',
                data : {id:id},
                success : function() {
                    window.location.href = 'all_users';
                }
            });
        }
        else {
            return false;
        }
         
    }

    function edit_user(id) {
        $.ajax({
                url : 'edit_user/'+id,
                method : 'POST',
                data : {id:id},
                success : function(data) {
                    // window.location.href = 'edit_user';
                    $('#here').html(data);
                }
        });
    }

</script>