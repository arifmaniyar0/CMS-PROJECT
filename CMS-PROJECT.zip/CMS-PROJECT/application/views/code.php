<?php $this->load->view('includes/login_header.php'); ?>


<div class="container">
	<h3><?php if($this->session->flashdata('code')) {
		echo $this->session->flashdata('code');
	} ?></h3>

	<div class="row">
		<div class="col-lg-6 col-lg-offset-3">	
		
			<div class="alert alert-success alert-dismissible" role="alert">
				<button type="button" class="close" data-dismiss="alert">
					<span aria-hidden="true">×</span><span class="sr-only">Close</span>
				</button>We have a sent a security code to your email <span><?= $email; ?>  
					
		</span>
			</div>	
			<?php if($this->session->flashdata('error')) { ?>	
				<div class="alert alert-danger alert-dismissible text-center" role="alert">
				<button type="button" class="close" data-dismiss="alert">
					<span aria-hidden="true">×</span><span class="sr-only">Close</span>
				</button><?php echo $this->session->flashdata('error'); ?> 
			</div>
			<?php } ?>			
		</div>
	</div>

    <div class="row">
				<div class="col-lg-6 col-lg-offset-3 col-md-6 col-md-offset-3">
					<div class="alert-placeholder">
	
					</div>
					<div class="panel panel-success">
						<div class="panel-body">
							<div class="row">
								<div class="col-lg-12">
									<div class="text-center"><h2><b> Enter Code</b></h2></div>
									<form id="register-form" action="<?= base_url() ?>submit_code?email=<?php echo $email ?>&code=<?php echo $code ?>"  method="post" role="form" autocomplete="off">
										<div class="form-group">
											<input type="text" name="code" id="code" tabindex="1" class="form-control" maxlength="6" placeholder="##########" onkeypress="return isNumber()" value="" autocomplete="off" required/>
										</div>
										<div class="form-group">
											<div class="row">

												<div class="col-lg-3 col-lg-offset-2 col-md-3 col-md-offset-2 col-sm-3 col-sm-offset-2  col-xs-6">
													<input type="submit" name="code-cancel" id="code-cancel" tabindex="2" class="form-control btn btn-danger" value="Cancel" />
			
												</div>
												<div class="col-lg-3 col-lg-offset-2 col-md-3 col-md-offset-2 col-sm-3 col-sm-offset-2 col-xs-6">
													<input type="submit" name="code-submit" id="recover-submit" tabindex="2" class="form-control btn btn-success" value="Continue" />
													
												</div>

											</div>
										</div>
										<input type="hidden" class="hide" name="token" id="token" value="">
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

<script type="text/javascript">
	
	function isNumber() {
		if(event.keyCode < 48 || event.keyCode > 57) {
			return false;
		}
		return true;
	}
	
</script>
			
<?php $this->load->view('includes/login_footer.php'); ?>
	