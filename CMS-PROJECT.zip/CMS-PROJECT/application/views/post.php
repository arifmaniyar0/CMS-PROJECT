<?php $this->load->view('includes/navigation'); ?>

    <!-- Page Content -->
    <div class="container">

        <div class="row">

            <!-- Blog Post Content Column -->
            <div class="col-lg-8">

                <!-- Blog Post -->

                <!-- Title -->

                <h1><?php echo $post->post_title; ?></h1>

                <!-- Author -->
                <p class="lead">
                    by <a href="#"><?= $post->post_author ?></a>
                </p>

                <hr>

                <!-- Date/Time -->
                <p><span class="glyphicon glyphicon-time"></span> Posted on <?php echo $post->post_date; ?></p>

                <hr>

                <!-- Preview Image -->
                <img class="img-responsive" src="<?= base_url(); ?>assets/images/<?= $post->post_image; ?>" alt="">

                <hr>

                <!-- Post Content -->
                <p class="lead"><?= $post->post_content; ?></p>
                

                <hr>

                <!-- Blog Comments -->

                <!-- Comments Form -->
                <div class="well">
                    <h4>Leave a Comment: <small class="text-danger" id="commentErr"></small></h4>
                    <form id="comment_form" action="<?= base_url() ?>create_new_comment/<?= $post->post_id; ?>" method='post' onsubmit="return comment_form(<?= $post->post_id; ?>)" role="form">
                        <div class="form-group">
                            <textarea id="comment_box" class="form-control" rows="3" name="comment"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form> 
                    
                </div>

                <hr><hr>

                <!-- Posted Comments -->

                <!-- Comment -->
                <h2>Comments</h2><hr>
                <?php $i = 1; foreach($comment as $c) {  $i++; ?>
                <div class="media">
                    <a class="pull-left" href="#">
                        <img class="media-object" src="http://placehold.it/64x64" alt="">
                    </a>
                    <div class="media-body">
                        <h4 class="media-heading"><?= $c->comment_author; ?>
                            <small><?= $c->comment_date; ?></small>
                        </h4>
                        <?= $c->comment_content; ?>
                    </div>
                </div><hr>
                <?php  } 
                if($i == 1) {
                    echo '<h4>No Comments found</h4>';
                }    ?>


                

            </div>




            <script type="text/javascript">
                


                    function comment_form(id) {
                        var comment = $('#comment_box').val();
                        console.log(id);
                         if(comment == '') {
                            $('#commentErr').text('comment box can not be empty');
                            return false;
                        }
                       return true;
                    }

            </script>

            <!-- Blog Sidebar Widgets Column -->
            <?php $this->load->view('includes/sidebar.php'); ?>
          