


    <!-- Navigation -->
    <?php //include('includes/navigation.php'); 
    $this->load->view('includes/navigation.php'); ?>

    <!-- Page Content -->
    <div class="container">

        <div class="row">

            <!-- Blog Entries Column -->
            <div class="col-md-8">

                <h1 class="page-header">
                    <div>
                    <?php if($this->session->userdata('username')) {
                        echo 'Welcome ';
                        echo '<small>'.$this->session->userdata('username').'</small>';
                    } ?>
                    </div>
                </h1>

                <!-- Blog Post -->
                <div id="search_result">
                <?php foreach($posts as $post) { ?>
                <h2>
                    <a href="<?= base_url(); ?>post/<?= $post->post_id; ?>"><?= $post->post_title; ?></a>
                </h2>
                <p class="lead">
                    by <a href=""><?= $post->post_author ?></a>
                </p>
                <p><span class="glyphicon glyphicon-time"></span> Posted on <?= $post->post_date; ?></p>
                <hr>
                <a href="<?= base_url(); ?>post/<?= $post->post_id; ?>">
                    <img class="img-responsive" src="<?= base_url(); ?>assets/images/<?= $post->post_image; ?>" alt=""></a>
                <hr>
                <p><?= $post->post_content; ?></p>
                <a class="btn btn-primary" href="post/<?= $post->post_id; ?>">Read More <span class="glyphicon glyphicon-chevron-right"></span></a>

                <hr>

                <?php } ?>
                </div>
                <!-- Pager -->
                <ul class="pager">
                    <?= $this->pagination->create_links(); ?>
                </ul>

            </div>

            <!-- Blog Sidebar Widgets Column -->
            
            <?php $this->load->view('includes/sidebar.php'); ?>
            <!-- /.row -->

            <hr>

            <!-- Footer -->

<script type="text/javascript">
    
    $(document).ready(function() {
    $('#input_search').on('keyup',function() {
        var query = $('#input_search').val();
        if(query != '') {

                $.ajax({
                    url : 'posts/search/'+query,
                    method : 'POST',
                    data : {query:query},
                    success : function(data) {
                        $('#search_result').html(data);
                        
                    }
                });
            }
    });
});

</script>