<?php $this->load->view('includes/login_header.php'); ?>


	
	
<div class="container">

	

	<div class="row">
		<div class="col-lg-6 col-lg-offset-3">

	
								
		</div>
	</div>
    	<div class="row">
    		<?php if($this->session->flashdata('error')) { ?>
    		<div class="col-md-6 col-md-offset-3">
    			<div class="alert alert-danger alert-dismissible text-center">
    		 		<?php echo $this->session->flashdata('error'); ?> 
				</div>
			</div>
    		 <?php } ?>
				
				<?php if($this->session->flashdata('signup_success')) { ?>

						<div class="col-md-6 col-md-offset-3">
    		<div class="alert alert-success alert-dismissible text-center">

						<?php echo $this->session->flashdata('signup_success'); ?>

						</div></div>

				<?php } ?>
				
			<div class="col-md-6 col-md-offset-3">
				<div class="panel panel-login">
					<div class="panel-heading">
						<div class="row">
							<div class="col-xs-6">
								
								<a href="<?php echo base_url('login') ?>" class="active" id="login-form-link">Login</a>
							</div>
							<div class="col-xs-6">
								<a href="<?php echo base_url('signup') ?>" id="">Register</a>
							</div>
						</div>
						<hr>
					</div>
					<div class="panel-body">
						<div class="row">
							<div class="col-lg-12">
								<form id="login-form" action="user_signin"  method="post" role="form" style="display: block;">
									<div class="form-group">
										<input type="text" name="email" id="email" tabindex="1" class="form-control" placeholder="Email" required><small id="login_email"></small>
									</div>
									<div class="form-group">
										<input type="password" name="password" id="password"
										 tabindex="2" class="form-control" placeholder="Password" required><small id="login_password"></small>
									</div>
									<div class="form-group text-center">
										<input type="checkbox" tabindex="3" class="" name="remember" id="remember">
										<label for="remember"> Remember Me</label>
									</div>
									<div class="form-group">
										<div class="row">
											<div class="col-sm-6 col-sm-offset-3">
												<input type="submit" name="login-submit" id="login-submit" tabindex="4" class="form-control btn btn-login" value="Log In">
											</div>
										</div>
									</div>
									<div class="form-group">
										<div class="row">
											<div class="col-lg-12">
												<div class="text-center">
													<a href="<?php echo base_url('recover') ?>" tabindex="5" class="forgot-password">Forgot Password?</a>
												</div>
											</div>
										</div>
									</div>
								</form>
								
							</div>
						</div>
					</div>
				</div>
			</div>

		</div>


<script type="text/javascript">
	
$(document).ready(function() {

	$('#email').change(function(){

		var email = $('#email').val();

		if(email != '') {

			$.ajax({
				url:'<?php echo base_url("login/sign_user"); ?>',
				method:'POST',
				data:{email:email},
				success:function(data) {
					$('#login_email').html(data);
				}
			});

		}
	});


});


</script>


<?php $this->load->view('includes/login_footer.php'); ?>
