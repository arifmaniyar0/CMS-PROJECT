<?php 


class Test
{
	public $name;
	public function ShowName()
	{
		echo "Name is $this->name";
	}
	public function validate()
	{
		
	}
}

$nameArray = array('Arif','rk','shashi','ravi','partho','vikki','manoj');
$a = new Test();
$a->name = $nameArray[rand(0,count($nameArray)-1)];
$a->ShowName();
echo "<br>";
echo "<pre>";
$arr = range('a', 'z');
echo($arr[rand(0,count($arr)-1)]);

 ?>