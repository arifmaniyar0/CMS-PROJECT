</div> <!--Container-->


	<script src="<?php echo base_url(); ?>assets/js/bootstrap.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/scripts.js"></script>

	
</body>
</html>