
<?php if(empty($search)) { ?>

    <h1>No Records Found</h1>

<?php } else { ?>

    <?php foreach($search as $s) { ?>

        <h2>
            <a href="post/<?= $s->post_id; ?>"><?= $s->post_title; ?></a>
        </h2>
        <p class="lead">
            by <a href=""><?= $s->post_author; ?></a>
        </p>
        <p><span class="glyphicon glyphicon-time"></span> Posted on <?= $s->post_date; ?></p>
        <hr>
        <img class="img-responsive" src="<?= base_url(); ?>assets/images/<?= $s->post_image; ?>" alt="">
        <hr>
        <p><?= $s->post_content; ?></p>
        <a class="btn btn-primary" href="post/<?= $s->post_id; ?>">Read More <span class="glyphicon glyphicon-chevron-right"></span></a>

        <hr>

    <?php } } ?>
