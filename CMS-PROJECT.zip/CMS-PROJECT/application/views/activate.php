<?php $this->load->view('includes/login_header.php'); ?>


	 
	
<div class="container">




	<div class="jumbotron">
		<h3 class="text-center"><?php if($this->session->flashdata('message')) {
		echo  $this->session->flashdata('message');
		}
		else {
			redirect('signup');
		} ?></h3>

		<div><?php 
		if($this->session->flashdata('link')) {
			echo $this->session->flashdata('link');
		}

		 ?></div>
	</div>

<?php $this->load->view('includes/login_footer.php'); ?>

	
