<?php



class Login_model extends CI_Model {

	public function __construct() {
		parent:: __construct();
		$this->load->database();
	}


	public function check_email($email) {
		if(filter_var($email,FILTER_VALIDATE_EMAIL)) {

			$this->db->where('user_email',$email);
			$this->db->where('user_active',1);
			$query = $this->db->get('users');
			if($query->num_rows() == 1) {
				return TRUE;
			}
			else {
				return FALSE;
			}
		}
		else {
			return TRUE;
		}
		
	}

	public function check_unverified_email($email) {
		if(filter_var($email,FILTER_VALIDATE_EMAIL)) {

			$this->db->where('user_email',$email);
			$this->db->where('user_active',0);
			$query = $this->db->get('users');
			if($query->num_rows() == 1) {
				return TRUE;
			}
			else {
				return FALSE;
			}
		}
		else {
			return TRUE;
		}
		
	}

	public function check_username() {

		$this->db->where('username',$this->input->post('username'));
		$query = $this->db->get('users');
		if($query->num_rows() == 1) {
			return TRUE;
		}
		else {
			return FALSE;
		}
	}

	public function user_register($data) {
		

		$this->db->insert('users',$data);
	}

	public function verify_user_account($email,$validation_code) {

		$this->db->where('user_email',$email);
		$this->db->where('validation_code',$validation_code);
		$query = $this->db->get('users');

		if($query->num_rows() == 1) {
			$this->db->where('user_email',$email);
			$this->db->where('validation_code',$validation_code);
			$this->db->set('validation_code',0);
			$this->db->set('user_active',1);
			$this->db->update('users');
		}


		
	}


	public function get_user_data($email) {
		
		$this->db->where('user_email',$email);
		$query = $this->db->get('users');
		if($query->num_rows() == 1) {
			return $query->row();
		}
	}


	public function password_reset_code($email,$validation_code) {
		$this->db->where('user_email',$email);
		$this->db->set('validation_code',$validation_code);
		$this->db->update('users');

	}


	public function check_recover_data($email,$code) {
		$this->db->where(array('user_email' => $email,'validation_code' => $code));
		$query = $this->db->get('users');
		if($query->num_rows() == 1) {
			return TRUE;
		}
		else {
			return FALSE;
		}
	}


	public function update_password($email,$validation_code,$password) {
		$this->db->where('user_email',$email);
		$this->db->where('validation_code',$validation_code);
		$this->db->set('user_password',$password);
		$this->db->set('validation_code',0);
		$this->db->update('users');
	}




	public function update_user_data($id,$firstname,$lastname,$username,$email) {

		$this->db->where('user_id',$id);
		$this->db->set('user_firstname',$firstname);
		$this->db->set('user_lastname',$lastname);
		$this->db->set('username',$username);
		$this->db->set('user_email',$email);
		$this->db->update('users');
	}





}














?>