<?php

class Admin_model extends CI_Model {

	public function __construct() {
		parent:: __construct();
		$this->load->database();
	}

	public function get_post() {
		$query = $this->db->order_by('post_id','DESC');
		$query = $this->db->get('posts');
		return $query->result();
	}

	public function delete_post($id) {
		$this->db->where('post_id',$id);
		$this->db->delete('posts');

		$this->db->where('comment_post_id',$id);
		$this->db->delete('comments');

	}

	public function view_editpost($id) {
		$this->db->where('post_id',$id);
		$query = $this->db->get('posts');
		return $query->result();
	}

	public function get_cat($id) {
		$this->db->where('cat_id',$id);
		$query = $this->db->get('categories');
		return $query->row();
	}

	public function category() {
		$query = $this->db->get('categories');
		return $query->result();
	}

	public function update_editpost($id,$file_name) {
		$this->db->where('post_id',$id);
		$this->db->set('post_title',$this->input->post('post_title'));
		$this->db->set('post_category_id',$this->input->post('post_category'));
		$this->db->set('post_author',$this->input->post('post_author'));
		$this->db->set('post_image',$file_name);
		$this->db->set('post_content',$this->input->post('post_content'));
		$this->db->set('post_status',$this->input->post('post_status'));
		$this->db->update('posts');
	}

	public function create_post($file_name) {
		$data = array(
			'post_title' => $this->input->post('post_title'),
			'post_category_id' => $this->input->post('post_category'),
			'post_author' => $this->input->post('post_author'),
			'post_content' => $this->input->post('post_content'),
			'post_tags' => $this->input->post('post_tags'),
			'post_image' => $file_name,
			'post_status' => $this->input->post('post_status')

		);
		$this->db->insert('posts',$data);
	}

	public function add_cat() {
		$this->db->insert('categories',array( 'cat_title' => $this->input->post('category')));
	}

	public function del_cat($id) {
		$this->db->where('cat_id',$id);
		$this->db->delete('categories');
	}


	public function get_editcat($id) {
		$this->db->where('cat_id',$id);
		$query = $this->db->get('categories');
		return $query->result();
	}

	public function update_category($id) {
		$this->db->where('cat_id',$id);
		$this->db->set('cat_title',$this->input->post('cat'));
		$this->db->update('categories');
	}


	public function all_users() {
		$query = $this->db->get('users');
		return $query->result();
	}


	public function del_user($id) {
		$this->db->where('user_id',$id);
		$this->db->delete('users');

		$this->db->where('comment_user_id',$id);
		$this->db->delete('comments');
	}


	public function user_data($id) {
		$this->db->where('user_id',$id);
		$query = $this->db->get('users');
		if($query->num_rows() == 1) {
			return $query->row();
		}
	}

	public function email_availability($email,$used_email) {
		$this->db->where('user_email',$email);
		$query = $this->db->get('users');
		if($query->num_rows() == 1) {
			// $data = $query->row();
			if($email == $used_email) {
				return FALSE;
			}
			else {
				return TRUE;
			}
		}
		else {
			return FALSE;
		}

	}

	public function username_availability($username,$used_username) {
		$this->db->where('username',$username);
		$query = $this->db->get('users');
		if($query->num_rows() == 1) {
			// $data = $query->row();
			if($username == $used_username) {
				return FALSE;
			}
			else {
				return TRUE;
			}
		}
		else {
			return FALSE;
		}
	}

	public function update_user_data($id,$firstname,$lastname,$username,$email) {
		$this->db->where('user_id',$id);
		$this->db->set('user_firstname',$firstname);
		$this->db->set('user_lastname',$lastname);
		$this->db->set('username',$username);
		$this->db->set('user_email',$email);
		$this->db->update('users');

	}


	public function create_new_user($firstname,$lastname,$username,$email,$password) {

		if(filter_var($email,FILTER_VALIDATE_EMAIL)) {

			$data = array(
				'user_firstname' => $firstname,
				'user_lastname' => $lastname,
				'username' => $username,
				'user_email' => $email,
				'user_password' => password_hash($password, PASSWORD_DEFAULT),
				'user_active' => 1
				);


			$this->db->insert('users',$data);
		}
	}


	public function all_comments() {
		$query = $this->db->order_by('comment_id','DESC');
		$query = $this->db->get('comments');
		return $query->result();
	}

	public function get_comment_post($id) {
		$this->db->where('post_id',$id);
		$query = $this->db->get('posts');
		if($query->num_rows() == 1) {
			return $query->row();
		}
	}


	public function user_delete($id) {
		$this->db->where('comment_id',$id);
		$this->db->delete('comments');
	}

	public function comment_approve($id) {
		$this->db->where('comment_id',$id);
		$this->db->set('comment_status','approved');
		$this->db->update('comments');
	}

	public function comment_unapprove($id) {
		$this->db->where('comment_id',$id);
		$this->db->set('comment_status','unapproved');
		$this->db->update('comments');
	}

	public function post_publish($id) {
		$this->db->where('post_id',$id);
		$this->db->set('post_status','published');
		$this->db->update('posts');
	}

	public function post_draft($id) {
		$this->db->where('post_id',$id);
		$this->db->set('post_status','draft');
		$this->db->update('posts');
	}


	public function total_posts() {
		$query = $this->db->get('posts');
		return $query->num_rows();
	}

	public function total_comments() {
		$query = $this->db->get('comments');
		return $query->num_rows();
	}

	public function total_users() {
		$query = $this->db->get('users');
		return $query->num_rows();
	}

	public function total_categories() {
		$query = $this->db->get('categories');
		return $query->num_rows();
	}


	public function count_comment($id) {
		$this->db->where('comment_post_id',$id);
		$query = $this->db->get('comments');
		return $query->num_rows();
	}


	public function post_clone($id) {
		$this->db->where('post_id',$id);
		$query = $this->db->get('posts');
		$data = $query->row();
		$insert_data = array(
			'post_title' => $data->post_title,
			'post_category_id' => $data->post_category_id,
			'post_author' => $data->post_author,
			'post_content' => $data->post_content,
			'post_image' => $data->post_image,
			'post_status' => $data->post_status

		);
		$this->db->insert('posts',$insert_data);
	}

	




}
?>