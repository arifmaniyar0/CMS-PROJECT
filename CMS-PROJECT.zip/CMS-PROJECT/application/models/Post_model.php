<?php


class Post_model extends CI_Model {

	public function __construct() {
		parent:: __construct();
		$this->load->database();
	}

	public function get_posts($limit,$offset) {
		
		$this->db->order_by('post_id','DESC');
		$this->db->limit($limit,$offset);
		$this->db->where('post_status','published');
		$query = $this->db->get('posts');
		if($query->num_rows() > 0) {
			return $query->result();
		}
		else {
			?>
			<script type="text/javascript">
				$('#search_result').html('<h1>No Record Found</h1>');
			</script>
			<?php
			return $query->result();
		}
		
	}

		public function all_posts() {
			$this->db->where('post_status','published');
			$query = $this->db->get('posts');
			return $query->num_rows();
		}

	public function all_category() {
		$query = $this->db->get('categories');
		return $query->result();
	}

	public function get_post($id) {
		$this->db->where('post_id',$id);
		$query = $this->db->get('posts');
		return $query->row();
	}

	public function search_data($query) {

		if($query != '') {
			$this->db->like('post_tags',$query);
			$this->db->or_like('post_title',$query);
			// $this->db->like('post_author',$query);
			// $this->db->like('post_content',$query);
		}

		$this->db->order_by('post_id','DESC');
		$query = $this->db->get('posts');
		
			return $query->result();
		
	}

	public function add_comment($id) {
		$u_id = $this->session->userdata('id');
		$user_firstname = $this->session->userdata('firstname');
		$user_lastname = $this->session->userdata('lastname');
		$user_email = $this->session->userdata('email');
		$comment_content = $this->input->post('comment');
		$data = array(
			'comment_post_id'=>$id,
			'comment_user_id'=>$u_id,
			'comment_author'=>$user_firstname.' '.$user_lastname,
			'comment_email'=>$user_email,
			'comment_content'=>$comment_content,
			'comment_status'=>'unapproved',
			);

		$this->db->insert('comments',$data);
	}


	public function get_comment($id) {
		$this->db->where('comment_post_id',$id);
		$this->db->where('comment_status','approved');
		$query = $this->db->get('comments');
		return $query->result();
	}

	public function SearchByCategory($cat)
	{
		$this->db->where('cat_title',$cat);
		$query = $this->db->get('categories');
		$CatData = $query->row();
		$id = $CatData->cat_id;
		return $id;
	}

	public function PostByCategory($id)
	{
		$this->db->where('post_category_id',$id);
		$query = $this->db->get('posts');
		return $query->result();
	}








}
?>