<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/



//----------- LOGIN -----------//
$route['reset_password'] = 'login/reset_password';
$route['reset'] = 'login/reset';
$route['recover_password'] = 'login/recover_password';
$route['logout'] = 'login/logout';
$route['recover'] = 'login/recover';
$route['user_signin'] = 'login/user_signin';
$route['user_verification'] = 'login/user_verification';
$route['submit_code'] = 'login/submit_code';
$route['code'] = 'login/code';
$route['activate'] = 'login/activate';
$route['login'] = 'login/index';
$route['do_signup'] = 'login/do_signup';
$route['signup'] = 'login/signup';


//---------- \END LOGIN ---------//



//---------- ADMIN -------------//

$route['checkboxes'] = 'admin/checkboxes';
$route['unapprove_comment/(:any)'] = 'admin/unapprove_comment/$1';
$route['approve_comment/(:any)'] = 'admin/approve_comment/$1';
$route['delete_comment/(:any)'] = 'admin/delete_comment/$1';
$route['comments'] = 'admin/comments';
$route['submit_new_user'] = 'admin/submit_new_user';
$route['add_user'] = 'admin/add_user';
$route['update_user/(:any)'] = 'admin/update_user/$1';
$route['edit_user/(:any)'] = 'admin/edit_user/$1';
$route['delete_user/(:any)'] = 'admin/delete_user/$1';
$route['all_users'] = 'admin/all_users';
$route['add_category'] = 'admin/add_category';
$route['delete_cat/(:num)'] = 'admin/delete_cat/$1';
$route['update_category/(:num)'] = 'admin/update_category/$1';
$route['update_cat/(:num)'] = 'admin/update_cat/$1';
$route['categories'] = 'admin/categories';
$route['create_post'] = 'admin/create_post';
$route['add_post'] = 'admin/add_post';
$route['update_post/(:num)'] = 'admin/update_post/$1';
$route['edit_post/(:num)'] = 'admin/edit_post/$1';
$route['delete_post/(:num)'] = 'admin/delete_post/$1';
$route['draft_post/(:num)'] = 'admin/draft_post/$1';
$route['publish_post/(:num)'] = 'admin/publish_post/$1';
$route['all_posts'] = 'admin/all_posts';
$route['admin'] = 'admin/index';

//------------ \END ADMIN -----------//


//------------- POST --------------//

$route['SearchByCategory/(:any)'] = 'posts/SearchByCategory/$1';
$route['error'] = 'posts/error';
$route['create_new_comment/(:num)'] = 'posts/create_new_comment/$1';
$route['search/(:any)'] = 'posts/search/$1';
$route['search'] = 'posts/search';
$route['post/(:num)'] = 'posts/post/$1';
$route['post'] = 'posts/post';

//----------- END POST ------------//

//---------  DEFAULT CONTROLLER -----------//
$route['default_controller'] = 'posts';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
