

// search = document.getElementById('input_search');



// search.addEventListener('keyup',function() {

// 	var query = search.value;
// 	console.log(query);

// 	if(query != '') {

// 		var obj = new XMLHttpRequest();

// 		obj.onreadystatechange = function() {

// 			if(this.readyState == 4 && this.status == 200)
// 			{
// 				document.getElementById('search_result').innerHTML = this.responseText;
// 			}

// 		};

// 		obj.open("POST","posts/search/"+query,true);
// 		obj.send();
// 	} 
// });


$(document).ready(function() {
	$('#input_search').on('keyup',function() {
		var query = $('#input_search').val();
		if(query != '') {

				$.ajax({
					url : 'posts/search/'+query,
					method : 'POST',
					data : {query:query},
					success : function(data) {
						$('#search_result').html(data);
						
					}
				});
			}
	});
});

