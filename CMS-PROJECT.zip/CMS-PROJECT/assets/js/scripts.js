$(function(){


    // $("#register_email").on('change', function(){


    // var email = $(this).val();



    // $.post("ajax_functions.php", {email : email}, function(data){

    

    //     $(".db-feedback").html(data);

    // });




    // });

   





    $('#login-form-link').click(function(e) {
        $("#login-form").delay(100).fadeIn(100);
        $("#register-form").fadeOut(100);
        $('#register-form-link').removeClass('active');
        $(this).addClass('active');
        e.preventDefault();
    });
    $('#register-form-link').click(function(e) {
        $("#register-form").delay(100).fadeIn(100);
        $("#login-form").fadeOut(100);
        $('#login-form-link').removeClass('active');
        $(this).addClass('active');
        e.preventDefault();
    });



  




});


//******** signup jquery ********//

// $(document).ready(function() {


//     var fname = false;
//         var lname = false;
//         var uname = false;
//         var gmail = false;
//         var pass = false;
//         var cpass = false;


// $('#firstname_check').hide();
// $('#lastname_check').hide();
// $('#password_check').hide();
// $('#con_password_check').hide();

    

//     function check_firstname() {
//         $('#firstname').focusout(function() {
//             var firstname = $('#firstname').val();
//             if(firstname === '') {
//                 $('#firstname_check').show();
//                 $('#firstname_check').html('Enter firstname');
//                 fname = false;
//             }
//             else { 
//                 $('#firstname_check').hide();
//                 fname = true;
//            }
//         });
//     } 
    
//     function check_lastname() {
//         $('#lastname').focusout(function() {
//             var lastname = $('#lastname').val();
//             if(lastname === '') {
//                 $('#lastname_check').show();
//                 $('#lastname_check').text('Enter lastname');
//                 lname = false;
//             }
//             else {
//                 $('#lastname_check').hide();
//                 lname = true;
//             }
//         });
//     }

//     function check_email() {
//         var bool = false;
//         $('#register_email').change(function() {
//             var email = $('#register_email').val();
            
//             if(email != '') {

//                 $.ajax({
//                     url : '<?php echo base_url() ?>login/email_exist',
//                     method : 'POST',
//                     data : {email:email},
//                     success : function(data) {

//                         $('#email_check').html(data);
                        
//                     }
//                 });
//             }
//         });
//     }



//     function check_username() {
//         $('#username').change(function() {
//             var username = $('#username').val();
//             console.log(username);
//             if(username != '') {
//                 $.ajax({
//                     url : '<?php echo base_url() ?>login/username_exist',
//                     method : 'POST',
//                     data : {username : username},
//                     success : function(data) {
//                         $('#username_check').html(data);
//                     }
//                 });
//             }
//         });
//     }

//     function check_password() {
//         $('#password').focusout(function() {
//             var password = $('#password').val();
//             if(password === '') {
//                 $('#password_check').show();
//                 $('#password_check').text('Enter password');
//                 pass = false;
//             }
//             else {
//                 if(password.length < 5) {
//                     $('#password_check').show();
//                     $('#password_check').text(' password must be at least 6 character long');
//                     pass = false;
//                 }
//                 else {
//                     $('#password_check').hide();
//                     pass = true;
//                 }
//             }
            
//         });
//     }

//     function check_con_password() {
//         $('#con_password').change(function() {
//             var con_password = $('#con_password').val();
//             if(con_password === '') {
//                 $('#con_password_check').show();
//                 $('#con_password_check').text('Enter password');
//                 cpass = false;
//             }
//             else {
//                 if($('#password').val() != $('#con_password').val()) {
//                     $('#password_check').show();
//                     $('#password_check').text('password not matched');
//                     cpass = false;
//                 }
//                 else {
//                     $('#con_password_check').hide();
//                     cpass = true;
//                 }
                
//             }
//         });
//     }

        
    
        
//     var fname = false;
//         var lname = false;
//         var pass = false;
//         var cpass = false;

//         check_firstname();
//         check_lastname();
//         uname = check_username();
//         gname = check_email();
//         check_password();
//         check_con_password();


        

//     $('#register_form').on('submit',function(event) {

        
//         if(fname == true && lname == true && pass == true && cpass == true) {
//             return true;
//         }
//         else {
//             return false;
//         }
//     });


// });

//******end jquery*********//
