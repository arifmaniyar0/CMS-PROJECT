function edit_cat(id) {

        var req = new XMLHttpRequest();

        req.onreadystatechange = function() {
        	
            if(this.readyState == 4 && this.status == 200)
            {
                document.getElementById('edit_form').innerHTML = this.responseText;
            }
        };

        req.open("POST","update_cat/"+id,true);
        req.send();

}



function delete_cat(id) {


    if(confirm('are you sure?')) {

        var req = new XMLHttpRequest();

        req.onreadystatechange = function() {
            
            if(this.readyState == 4 && this.status == 200)
            {
                // document.getElementById('edit_form').innerHTML = this.responseText;
                window.location.href = "categories";
            }
        };

        req.open("POST","delete_cat/"+id,true);
        req.send();
                
    }
    else {
        return false;
    }

     
}



// function del_user(id) {

//      var req = new XMLHttpRequest();

//         req.onreadystatechange = function() {
            
//             if(this.readyState == 4 && this.status == 200)
//             {
//                 // document.getElementById('edit_form').innerHTML = this.responseText;
//                 window.location.href = "all_users";
//             }
//         };

//         req.open("POST","delete_user/"+id,true);
//         req.send();
// }
